module Data_Memory(Clk , Data_in , Address , MemRd , MemWr , Data_out);
	input Clk , MemRd , MemWr;
	input [31:0] Data_in , Address;
	output reg [31:0] Data_out;
	
	reg [31:0] RAM[4095:0];
	initial begin
		$readmemh("C:\\Users\\Admin\\Desktop\\arc_2\\proj2\\p2\\src\\Data_memo.txt",RAM);
	end
	//initial $display("at time = %0d , MEM[0] = %0D, MEM[1] = %d", $time,RAM[0],RAM[1]);
	always @(*) begin
		if (Address[9:0] > 4095)
    		$display("WARNING: Invalid address %h", Address);
		if (MemRd) Data_out <= RAM[Address[9:0]];
		else Data_out = 32'hxxxxxxxx;
		end
		
	always @(posedge Clk) begin
		if(MemWr) begin
			RAM[Address] <= Data_in;
			dump_datamem();
		end
	end
	
	task dump_datamem;
  		integer i;
  		integer fd;
  		begin
    		fd = $fopen("C:\\Users\\Admin\\Desktop\\arc_2\\proj2\\p2\\src\\Data_memo.txt", "w");
    		if (fd == 0) begin
      		$display("ERROR: Could not open RegisterFile.txt for writing.");
    		end else begin
      		for (i = 0; i < 16; i = i + 1) begin
        		$fdisplay(fd, "%h", RAM[i]);
      		end
      		$fclose(fd);
      		$display("Data_memo.txt updated.");
    		end
  		end
	endtask
	endmodule
	
	
module DataMemo_Test();
	reg clk , Rd , Wr;
	reg [31:0] addr , d_in;
	wire [31:0] d_out;
	
	Data_Memory DM(clk , d_in , addr ,Rd, Wr, d_out);
	initial begin
		$monitor("time = %0d, Address = %h ,Data_in = %h, MemWr = %b , MemRd = %b, Data_out = %h",$time ,addr,d_in,Wr,Rd ,d_out);
		clk = 0;
		// write ABCDEF00 at MEM[0]
		#10; addr = 0; Wr = 1 ; Rd = 0; d_in = 32'hABCDEF00;
		// read at MEM[0] 
		#15 addr = 0; Wr = 0; Rd = 1; d_in = 32'hxxxxxxxx;
		#15 addr = 3; Wr = 0; Rd = 1; d_in = 32'hxxxxxxxx;
		#10 $finish;
	end
	always #5 clk = ~clk;
	endmodule
	