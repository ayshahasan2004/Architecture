module Splitter (input [31:0]instruction ,output [5:0] opcode ,output reg [3:0] Rs , Rt ,	Rd ,output [13:0] imm,output reg exception);
	
	assign opcode = instruction[31:26];
    assign Rd = instruction[25:22];
    
    assign Rt = instruction[17:14];
    assign imm = instruction[13:0];
	always @(opcode)begin	
		if (opcode == 6'd10 || opcode == 6'd11 || opcode == 6'd12)
			assign Rs = instruction[25:22];
		else
			assign Rs = instruction[21:18];
		
		if (opcode == 6'd13)
			assign Rs = 4'd14;
		end
		
	always @(*) begin
		exception = 0;
		if (opcode == 6'd8 && Rd[0] ==1) begin // LDW with odd Rd
			exception = 1;
			$display(" Exception: LDW destination register must be even. Rd = %d", Rd);
			$stop;
		end
		if (opcode == 6'd9 && Rs[0] ==1) begin // SDW with odd Rs
			exception = 1;
			$display(" Exception: SDW source register must be even. Rs = %d", Rs);
			$stop;
		end
			
	end
endmodule

module Split_Test();
	reg [31:0] Inst;
	wire [5:0] op;
	wire [3:0] s , t , d;
	wire [13:0] im;
	wire exc;
	Splitter D(Inst, op ,s , t ,d ,im,exc);
	initial begin
		Inst = 32'h10483FFF;	
		#10 $display("1-");
		$display("OPCode : %d, Rd = %d, Rs = %d, Rt = %d, imm = %d",op, d, s, t, im);
		Inst = 32'h14C4002A;
		#10 $display("2-");
		$display("OPCode : %d, Rd = %d, Rs = %d, Rt = %d, imm = %d",op, d, s, t, im);
		#10 $finish;
	end
	endmodule