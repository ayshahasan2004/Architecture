module Adder (input  [31:0] A, input  [31:0] B, output [31:0] Sum);			  
	wire [31:0] CarryOut;
    assign {CarryOut, Sum} = A + B;
endmodule
