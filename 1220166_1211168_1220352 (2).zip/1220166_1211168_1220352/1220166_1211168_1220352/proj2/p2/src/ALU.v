module ALU (input wire [3:0] ALUOP,
	input wire signed [31:0] Rs1, Rs2,
	output reg signed [31:0] AluOut,
	output reg zero,
	output reg sign
	);
always @(*) begin
  
    AluOut = 0;
    zero = 0;
    sign = 0;

    case (ALUOP)
        4'b0000: AluOut = Rs1 | Rs2;           
        4'b0001: AluOut = Rs1 + Rs2;          
        4'b0010: AluOut = Rs1 - Rs2;          
	  	4'b0011: begin
           if (Rs1 == 0)
               AluOut = 32'd0;
           else if (Rs1 < 0)
              AluOut = -1;
           else
             AluOut = 1;
      end           
        
       
        default: AluOut = 32'd0;
    endcase
	zero = (AluOut == 0);
    sign = (AluOut < 0);
end

endmodule
