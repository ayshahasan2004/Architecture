module PC_Ctrl (input [5:0] opcode , input zero_flag,sign_flag,DW_inst , output reg [1:0] Pc_Src);
	always @(*) begin
		case(opcode)
			6'd0:begin // OR
				Pc_Src = 0;
			end
			6'd1: begin // ADD 
				Pc_Src = 0;
			end
			6'd2: begin // SUB
				Pc_Src = 0;
			end
			6'd3: begin // CMP
				Pc_Src = 0;
			end
			6'd4: begin // ORI
				Pc_Src = 0;
			end
			6'd5: begin // ADDI
				Pc_Src = 0;
			end
			6'd6: begin // LW
				Pc_Src = 0;
			end
			6'd7: begin // SW
				Pc_Src = 0;
			end
			6'd8: begin // LDW
				if(DW_inst) Pc_Src = 3;
				else Pc_Src = 0;
			end
			6'd9: begin //SDW
				if(DW_inst) Pc_Src = 3;
				else Pc_Src = 0;
			end
			6'd10: begin // BZ
				if (zero_flag) Pc_Src = 1;
				else Pc_Src = 0;
			end
			6'd11: begin // BGZ
				if (!sign_flag && !zero_flag) Pc_Src = 1;
				else Pc_Src = 0;
			end
			6'd12: begin // BLZ
				if (sign_flag && !zero_flag) Pc_Src = 1;
				else Pc_Src = 0;
			end
			6'd13: begin // JR
				Pc_Src = 2;
			end
			6'd14: begin //J
				Pc_Src = 1;
			end
			6'd15: begin // CLL
				Pc_Src = 1;
			end	
		endcase
		end
		endmodule
		
		
module tb_PC_Ctrl;
    // Inputs
    reg [5:0] opcode;
    reg zero_flag;
    reg sign_flag;
    reg Stall;

    // Output
    wire [1:0] Pc_Src;

    // Instantiate the Unit Under Test (UUT)
    PC_Ctrl uut (
        .opcode(opcode),
        .zero_flag(zero_flag),
        .sign_flag(sign_flag),
        .DW_inst(Stall),
        .Pc_Src(Pc_Src)
    );

    // Task to display result
    task show_output;
        begin
            #1 $display("Time: %0t | Opcode: %0d | ZF: %b | SF: %b | Stall: %b | Pc_Src: %b",
                        $time, opcode, zero_flag, sign_flag, Stall, Pc_Src);
        end
    endtask

    initial begin
        $display("=== Starting PC_Ctrl Testbench ===");

        // Default flags
        zero_flag = 0;
        sign_flag = 0;
        Stall = 0;

        // R-type and I-type instructions (Pc_Src should be 0)
        opcode = 0;  show_output(); // OR
        opcode = 1;  show_output(); // ADD
        opcode = 2;  show_output(); // SUB
        opcode = 3;  show_output(); // CMP
        opcode = 4;  show_output(); // ORI
        opcode = 5;  show_output(); // ADDI
        opcode = 6;  show_output(); // LW
        opcode = 7;  show_output(); // SW

        // LDW (Stall doesn't affect Pc_Src value here)
        opcode = 8;  Stall = 1; show_output();
        Stall = 0; show_output();

        // SDW
        opcode = 9;  Stall = 1; show_output();
        Stall = 0; show_output();

        // BZ (Pc_Src = 1 if zero_flag is set)
        opcode = 10; zero_flag = 1; show_output();
        zero_flag = 0; show_output();

        // BGZ (Pc_Src = 1 if sign_flag == 0)
        opcode = 11; sign_flag = 0; show_output();
        sign_flag = 1; show_output();

        // BLZ (Pc_Src = 1 if sign_flag == 1)
        opcode = 12; sign_flag = 1; show_output();
        sign_flag = 0; show_output();

        // JR
        opcode = 13; show_output();

        // J
        opcode = 14; show_output();

        // CLL
        opcode = 15; show_output();

        $display("=== Testbench Finished ===");
        $stop;
    end
endmodule