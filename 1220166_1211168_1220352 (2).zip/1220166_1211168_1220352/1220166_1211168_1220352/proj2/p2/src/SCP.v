module SCP ();
	reg Clk, Clk2;
	wire Extender_Op;
	initial begin
        Clk = 0;
        forever #10ns Clk = ~Clk;
    end
	assign  Clk2 = Clk && ~stall && !lastinst;
	initial begin
        $display("=== Starting MakeThemTogeather Testbench ===\n");
        #300;  // Run for clock cycles
        $display("=== Finished Simulation ===");
        $stop;
		end
	always @(*) begin
		if (lastinst)begin
			#80;
			$stop;
		end
	end
	
	//PC Control
	reg zero_flag , sign_flag;
	PC_Ctrl PCC(.opcode(Instruction[31:26]), .zero_flag(EX_zero_flag), .sign_flag(EX_sign_flag), .DW_inst(DW_inst), .Pc_Src(PC_Source));
	
	// Instruction Fetch
	wire [31:0] next_PC,Instruction,Immediate; 
	wire [31:0] PC_plus_one = PC + 32'd1;
	wire [31:0] PC_plus_imm = PC + Immediate;
	reg [31:0] PC;
	wire [13:0] imm;
	reg [1:0] PC_Source ;
	wire DW_inst;
	reg last_DW;
	reg stall, lastinst;
	initial stall = 0;
	initial lastinst = 0;
	RegisterFile P_RF(.Clk(Clk2), .WE(1'b1) , .RA(4'd15) , .RB(4'd15) , .RW(4'd15) , .BusW(next_PC) ,.BusA(PC) ,.BusB()); // read PC from R15		
	Mux4_1 MX(.in0(PC_plus_one),.in1(PC_plus_imm),.in2(ALU_A),.in3(PC), .sel(PC_Source),.out(next_PC)); // choose next PC
	Instruction_Memory IM(.address(PC) , .instruction(Instruction));
	Main_Ctrl MC( .Opcode(Instruction[31:26]),.last_DW(last_DW), .RegB(RegB), .RegW(RegW), .RegW_2(RegW_2), .RegWr(RegWr), .ExtOp(Extender_Op), .AluSrc(ALU_Src), .MemRd(MemRd), .MemWr(MemWr), .WBdata(WB_sel), .DW_inst(DW_inst));
	wire [5:0] i = Instruction [31:26];
	always @(posedge Clk) begin
		last_DW = DW_inst;
	end
	always @(*) begin // check branches or hazards
		case (i)
			6'b001010: stall = 1;
			6'b001011: stall = 1;
			6'b001100: stall = 1;
			6'b001101: stall = 1;
		endcase
		if (Instruction[31:26] < 6'b000111 && ID_Inst_Op < 6'b000111) begin
			if (Instruction [25:22] == ID_Rd || Instruction [25:22] == ID_Rs || Instruction [25:22] == ID_Rt)
				stall = 1;
			else if (Instruction [21:18] == ID_Rd)
				stall = 1;
			else if (Instruction [17:14] == ID_Rd)
				stall = 1;
			end
		if (!Instruction)
			lastinst = 1;
	end
	Imm_Extender IE1(.Immediate(Instruction[13:0]) , .sel(1'b1) , .Extended(Immediate));
	

	reg [1:0] IF_RegW, IF_RegB, IF_AluSrc;
	/// ID-Pipeline
	reg [31:0] ID_Instruction, ID_PC_plus_one;
	reg [5:0] ID_Inst_Op  = Instruction [31:26];
	reg [3:0] ID_Rd = Instruction [25:22];
	reg [3:0] ID_Rs = Instruction [21:18];
	reg [3:0] ID_Rt = Instruction [17:14];
	reg [1:0] ID_RegB, ID_RegW, ID_AluSrc;
	reg ID_RegW_2 , ID_RegWr , ID_ExtOp  , ID_MemRd , ID_MemWr ,ID_WBdata, ID_DW_inst, ID_zero_flag, ID_sign_flag, ID_WB_sel;
	always @(posedge Clk) begin
		ID_Instruction <= Instruction;
		ID_RegW_2 <= RegW_2;
		ID_RegWr <= RegWr;
		ID_ExtOp <= Extender_Op;
		ID_MemRd <= MemRd;
		ID_MemWr <= MemWr;
		ID_WBdata <= WB_sel;
		ID_DW_inst <= DW_inst;
		ID_RegW <= RegW;
		ID_RegB <= RegB;
		ID_AluSrc <= ALU_Src;
		ID_WB_sel <= WB_sel;
		ID_PC_plus_one <= PC_plus_one;
		ID_Rd = Instruction [25:22];
		ID_Rs = Instruction [21:18];
		ID_Rt = Instruction [17:14];
		ID_Inst_Op = Instruction [31:26];
	end	
	
	
	//Instruction Decode
	wire [31:0] ALU_A, ALU_B, BusB, BusW,Immediate_zero_ext, Imm_z_plus_one;
	wire [5:0] Opcode;
	wire [3:0] RA, Rt_address, Rd_address, RB, RW, Rd_plus_one;//addresses in RegisterFile
	reg exception, RegWr;
	reg [1:0] RegB, RegW, ALU_Src;
	
	Splitter SP(.instruction(ID_Instruction), .opcode(Opcode), .Rs(RA), .Rt(Rt_address), .Rd(Rd_address), .imm(imm), .exception(exception));
	
	assign Rd_plus_one = Rd_address + 1;
	Imm_Extender IE2(.Immediate(ID_Instruction[13:0]) , .sel(1'b0) , .Extended(Immediate_zero_ext));
	Adder A2(.A(Immediate_zero_ext),.B(1),.Sum(Imm_z_plus_one));
	Mux3_1_4bit MX1(.in0(Rt_address), .in1(Rd_address),.in2(Rd_plus_one), .sel(ID_RegB), .out(RB));
	Mux3_1_4bit MX2(.in0(Rd_address), .in1(4'b1110), .in2(Rd_plus_one), .sel(ID_RegW), .out(RW));
	RegisterFile RF(.Clk(Clk), .WE(WB_RegWr) , .RA(RA) , .RB(RB) , .RW(WB_RW) , .BusW(WB_BusW) ,.BusA(ALU_A) ,.BusB(BusB));
	Mux3_1 MX4(.in0(BusB),.in1(Immediate_zero_ext), .in2(Imm_z_plus_one), .sel(ID_AluSrc),.out(ALU_B));
	always @(posedge Clk) begin
		if (stall == 1 && Opcode == 6'b001101) // at JR , because Rs is found out here
			stall = 0;
		end
	
	/// Execution Pipeline
	reg [31:0] EX_Instruction, EX_ALU_A, EX_ALU_B, EX_BusB, EX_PC_plus_one;
	reg [5:0] EX_Opcode;
	reg [3:0] EX_RW;
	reg [1:0] EX_RegB, EX_RegW, EX_AluSrc;
	reg EX_RegW_2 , EX_RegWr , EX_ExtOp  , EX_MemRd , EX_MemWr ,EX_WBdata, EX_DW_inst, EX_zero_flag, EX_sign_flag, EX_WB_sel;
	always @(posedge Clk) begin
		EX_RegW_2 <= ID_RegW_2;
		EX_RegWr <= ID_RegWr;
		EX_MemRd <= ID_MemRd;
		EX_MemWr <= ID_MemWr;
		EX_WBdata <= ID_WBdata;
		EX_DW_inst <= ID_DW_inst;
		EX_ALU_A <= ALU_A;
		EX_ALU_B <= ALU_B;
		EX_Opcode <= Opcode;
		EX_BusB <= BusB;
		EX_WB_sel <= ID_WB_sel;
		EX_PC_plus_one <= ID_PC_plus_one;
		EX_RW <= RW;
		EX_RegWr <= ID_RegWr;
	end	
	
	//ALU Control
	ALU_Ctrl AC(.Opcode(EX_Opcode), .ALU_Op(ALU_op));
	
	//Execution
	
	wire [3:0] ALU_op;
	wire [31:0] ALU_Result;
	reg WB_sel;
	wire zf,sf;
	assign EX_zero_flag = zf;
	assign EX_sign_flag = sf;
	ALU alu_inst(.ALUOP(ALU_op), .Rs1(EX_ALU_A), .Rs2(EX_ALU_B), .AluOut(ALU_Result), .zero(zf), .sign(sf));
	always @(posedge Clk) begin
		case (EX_Opcode)
			6'b001010: stall = 0;
			6'b001011: stall = 0;
			6'b001100: stall = 0;
			// make stall = 0 at branch cases (done checking if gt/lt/zero by flags)
		endcase
	end
	
	
	///Data Memory Pipeline
	reg [31:0] DM_BusB, DM_ALU_Result, DM_PC_plus_one;
	reg [3:0] DM_RW; 
	reg DM_MemRd, DM_MemWr, DM_WB_sel, DM_RegW_2, DM_RegWr;
	always @(posedge Clk) begin
		DM_BusB <= EX_BusB;
		DM_ALU_Result <= ALU_Result;
		DM_MemRd <= EX_MemRd;
		DM_MemWr <= EX_MemWr;
		DM_WB_sel <= EX_WB_sel;	
		DM_RegW_2 <= EX_RegW_2;
		DM_PC_plus_one <= EX_PC_plus_one;
		DM_RW <= EX_RW;
		DM_RegWr <= EX_RegWr;
	end
		
	//Data Memory
	wire [31:0] DataMem_out,WB_mux_out;
	reg RegW_2,MemRd, MemWr;
	Data_Memory DM(.Clk(Clk), .Data_in(DM_BusB), .Address(DM_ALU_Result), .MemRd(DM_MemRd), .MemWr(DM_MemWr), .Data_out(DataMem_out));
	
	///WriteBack Pipeline
	reg [31:0] WB_ALU_Result, WB_DataMem_out, WB_PC_plus_one, WB_BusW;
	reg [3:0] WB_RW;
	reg WB_RegW_2, WB_WB_sel, WB_stall, WB_RegWr;
	always @(posedge Clk) begin
		WB_ALU_Result <= DM_ALU_Result;
		WB_DataMem_out <= DataMem_out;
		WB_PC_plus_one <= DM_PC_plus_one;
		WB_RegW_2 <= DM_RegW_2;
		WB_WB_sel <= DM_WB_sel;
		WB_RW <= DM_RW;
	end
	
	
	
	//WriteBack
	Mux2_1_31bit MX5(.in0(WB_ALU_Result),.in1(WB_DataMem_out),.sel(WB_WB_sel),.out(WB_mux_out));
	Mux2_1_31bit MX6(.in0(WB_mux_out),.in1(WB_PC_plus_one),.sel(WB_RegW_2),.out(BusW));
	always @(*)begin
	if(BusW)
		WB_RegWr = 1;
	else
		WB_RegWr = 0;
	end
	RegisterFile WBRF(.Clk(~Clk), .WE(WB_RegWr) , .RA() , .RB() , .RW(WB_RW) , .BusW(WB_BusW) ,.BusA() ,.BusB());

	//  Control Unit
	
	//Main Control
	//wire Extender_Op;
//	Main_Ctrl MC(.Clk(Clk), .Opcode(Opcode), .RegB(RegB), .RegW(RegW), .RegW_2(RegW_2), .RegWr(RegWr), .ExtOp(Extender_Op), .AluSrc(ALU_Src), .MemRd(MemRd), .MemWr(MemWr), .WBdata(WB_sel), .DW_inst(DW_inst));
	

	

	
	always @(posedge Clk) begin
		$display("===> Instruction Fetch");
		$display("		Instruction : %h",Instruction);
		$display("		i : %b", i);
		$display("		PC : %d", PC);
		$display("		PC_plus_one : %d", PC_plus_one);
		$display("		PC_plus_imm : %d", PC_plus_imm); 
		$display("		Extended Imm : %d", Immediate);	
		$display("		next_PC : %d", next_PC);   
		$display("		PC_Source : %d", PC_Source);
		$display("		DW instruction : %d", DW_inst); 
		
		$display("===> Instruction Decode");
		$display("		Opcode : %d", Opcode);
		$display("		Rs(RA) : %d", RA);
		$display("		Rt : %d", Rt_address);
		$display("		Rd : %d", Rd_address);
		$display("		Extended_zero_imm : %h", Immediate_zero_ext);
		$display("		RegB : %d", ID_RegB);
		$display("		RB : %d", RB);
		$display("		RegW : %d", ID_RegW);
		$display("		RW : %d", RW);
		$display("		RegWr : %d", ID_RegWr);
		$display("		RF_BusA(ALU_A) : %h", ALU_A);
		$display("		RF_BusB : %h", BusB);
		$display("		ALU_Src : %d", ALU_Src);
		$display("		ALU_B : %h", ALU_B);
		
		$display("===> Execution");
		$display("		ALU_op : %d", ALU_op);
		$display("		ALU_Result : %h", ALU_Result); 
		$display("		zero_flag : %d", zf);
		$display("		sign_flag : %d", sf);
	
		$display("===> Data Memory");
		$display("		Data in : %d", DM_BusB);
		$display("		MemRd : %d", DM_MemRd);
		$display("		MemWr : %d", DM_MemWr);
		$display("		DataMem_out : %h", DataMem_out);
	
		$display("===> WriteBack");
		$display("		WB_sel : %d", WB_WB_sel);
		$display("		WB_mux_out : %h", WB_mux_out);
		$display("		RegW_2 : %d", WB_RegW_2);
		$display("		BusW : %h", BusW);
		$display("		WB_RW : %h", WB_RW);
		$display("		WB_RegWr : %h", WB_RegWr);

		$display("===> Control");
		$display("		DW : %d", DW_inst);
		$display("		Exception : %d", exception);
		$display("		stall : %d", stall);
		$display("		last insturction : %d", lastinst);
		$display("________________________________________");
		end
		
endmodule

module testbench_SCP;

    reg Clk;
	reg[31:0] Instruction;

    // Instantiate your top module
    SCP uut (
    );

    // Clock Generation (10ns period)
    initial begin
        Clk = 0;
        forever #10ns Clk = ~Clk;
    end


    // Simulation control
    initial begin
        $display("=== Starting MakeThemTogeather Testbench ===\n");
        #200;  // Run for ~7 clock cycles
        $display("=== Finished Simulation ===");
        $stop;
		forever if (uut.Instruction == 32'hxxxxxxxx) $finish;
    end

endmodule
