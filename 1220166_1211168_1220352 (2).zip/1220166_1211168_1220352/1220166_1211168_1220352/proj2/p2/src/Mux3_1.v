module Mux3_1 (
    input  [31:0] in0,
    input  [31:0] in1,
    input  [31:0] in2,
    input  [1:0]  sel,      // 2-bit select
    output reg [31:0] out
);
    always @(*) begin
        case (sel)
            2'b00: out = in0;
            2'b01: out = in1;
            2'b10: out = in2;
            default: out = 32'b0; // or assign 'x' or repeat in0
        endcase
    end
endmodule


module Mux3_1_4bit (
    input  [3:0] in0,
    input  [3:0] in1,
    input  [3:0] in2,
    input  [1:0]  sel,      // 2-bit select
    output reg [3:0] out
);
    always @(*) begin
        case (sel)
            2'b00: out = in0;
            2'b01: out = in1;
            2'b10: out = in2;
            default: out = 32'b0; // or assign 'x' or repeat in0
        endcase
    end
endmodule