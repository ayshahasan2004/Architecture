module RegisterFile(Clk ,WE , RA , RB , RW , BusW ,BusA ,BusB);
	input Clk , WE; 
	input [3:0] RA , RB , RW;
	input [31:0] BusW;
	output reg [31:0] BusA , BusB;				   
	reg [31:0] Registers[1023:0]; // 16 32-bit registers
	initial begin
		$readmemh("C:/Users/Admin/Desktop/arc_2/proj2/p2/src/RegisterFile.txt",Registers);
	end
	always @(posedge Clk) begin
		if (WE) begin			  
			Registers[RW] <= BusW; 
			dump_registers();
			end 
		end
	assign BusA = Registers[RA];
	assign BusB = Registers[RB];
	integer fd;

	task dump_registers;
  		integer i;
  		integer fd;
  		begin
    		fd = $fopen("C:/Users/Admin/Desktop/arc_2/proj2/p2/src/RegisterFile.txt", "w");
    		if (fd == 0) begin
      		$display("ERROR: Could not open RegisterFile.txt for writing.");
    		end else begin
      		for (i = 0; i < 16; i = i + 1) begin
        		$fdisplay(fd, "%h", Registers[i]);
      		end
      		$fclose(fd);					   
    		end
  		end
	endtask
	//initial $monitor("at time = %0d:\tR0 = %0d\tR1 = %0d\tR2 = %0d\tR3 = %0d\tR4 = %0d\tR5 = %0d\tR6 = %0d\tR7 = %0d\tR8 = %0d\nR9 = %0d\tR10 = %0d\tR11 = %0d\tR12 = %0d\tR13 = %0d\tR14 = %0d\tR15 = %0d"
	  //,$time,Registers[0],Registers[1],Registers[2],Registers[3],Registers[4],Registers[5],Registers[6],Registers[7],Registers[8],Registers[9],Registers[10],Registers[11],Registers[12],Registers[13],Registers[14],Registers[15]);
endmodule

`timescale 1ns/1ps

module RegisterFile_tb;

  reg Clk;
  reg WE;
  reg [3:0] RA, RB, RW;
  reg [31:0] BusW;
  wire [31:0] BusA, BusB;

  // Instantiate the RegisterFile
  RegisterFile uut (
    .Clk(Clk),
    .WE(WE),
    .RA(RA),
    .RB(RB),
    .RW(RW),
    .BusW(BusW),
    .BusA(BusA),
    .BusB(BusB)
  );

  // Clock generator: 10ns period
  always #5 Clk = ~Clk;

  integer i;

  initial begin
    // Initialize inputs
    Clk = 0;
    WE = 0;
    RA = 0;
    RB = 0;
    RW = 0;
    BusW = 0;

    $display("Starting test...");

    // Wait for 1 cycle
    #10;

    // Write 0xAAAA_BBBB to R1
    RW = 4'd1;
    BusW = 32'hAAAA_BBBB;
    WE = 1;
    #10;  // wait for posedge Clk

    // Write 0x1234_5678 to R2
    RW = 4'd2;
    BusW = 32'h1234_5678;
    WE = 1;
    #10;
	
	// Write 0x1234_0000 to R15 (must not write)
    RW = 4'd15;
    BusW = 32'h1234_0000;
    WE = 1;
    #10;
	
	// Write 0x1111_2222 to R0
    RW = 4'd0;
    BusW = 32'h1111_2222;
    WE = 1;
    #10;
	
    // Disable write
    WE = 0;
    RW = 4'd0;

    // Read from R1 and R2
    RA = 4'd1;
    RB = 4'd2;
    #10;

    $display("Read R1 = %h (expected: AAAA_BBBB)", BusA);
    $display("Read R2 = %h (expected: 1234_5678)", BusB);


    // Read R15
    WE = 0;
    RA = 4'd15;
    RB = 4'd0;
    #10;
    $display("Read R15 = %h (expected: 0000_0000)", BusA);

    // Dump all register values
    $display("\n==== Register File Dump ====");
    for (i = 0; i < 16; i = i + 1) begin
      $display("R%0d = %h", i, uut.Registers[i]);
    end
    $display("============================");
	uut.dump_registers();
    $display("Test completed.");
    $finish;
  end

endmodule
