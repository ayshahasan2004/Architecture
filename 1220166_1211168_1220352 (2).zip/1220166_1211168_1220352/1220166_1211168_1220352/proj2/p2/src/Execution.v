module Execution(
	input [31:0] A , B ,
	input [3:0] opcode,
	output [31:0] ALU_Result,
	output zero_flag, sign_flag);
	ALU alu_inst(.ALUOP(opcode), .Rs1(A), .Rs2(B), .AluOut(ALU_Result), .zero(zero_flag), .sign(sign_flag));
endmodule
