//module WB_data(
//	input [31:0] Data,ALU_Result, RegAddress,
//	input WBdata,Clk);
//	wire [31:0] Data_in;
//	wire [31:0] a1 , a2;
//	Mux2_1_31bit MX(.in0(Data), .in1(ALU_Result), .sel(WBdata), .out(Data_in));
//	RegisterFile RF(.Clk(Clk) , .WE(WBdata) , .RA(0) , .RB(0) , .RW(RegAddress) , .BusW(Data_in) ,.BusA(a1) ,.BusB(a2));
//endmodule
module WB_data(
	input [31:0] Data,ALU_Result, 
	input WBdata,
	output [31:0] WB_Out);
	wire [31:0] Data_in;
	wire [31:0] a1 , a2;
	assign WB_Out = WBdata ? Data : ALU_Result;
//	RegisterFile RF(.Clk(Clk) , .WE(WBdata) , .RA(0) , .RB(0) , .RW(RegAddress) , .BusW(Data_in) ,.BusA(a1) ,.BusB(a2));
endmodule