module ALU_Ctrl (input [5:0] Opcode , output reg [3:0] ALU_Op);
	always @(*) begin
		case(Opcode)
			6'd0:begin // OR
				ALU_Op = 0;
			end
			6'd1: begin // ADD 
				ALU_Op = 1;
			end
			6'd2: begin // SUB
				ALU_Op = 2;
			end
			6'd3: begin // CMP
				ALU_Op = 3;
			end
			6'd4: begin // ORI
				ALU_Op = 0;
			end
			6'd5: begin // ADDI
				ALU_Op = 1;
			end
			6'd6: begin // LW
				ALU_Op = 1; // Reg(Rs) + Imm
			end
			6'd7: begin // SW
				ALU_Op = 1; // Reg(Rs) + Imm
			end
			6'd8: begin // LDW
				ALU_Op = 1; // Reg(Rs) + Imm or Reg(Rs) + Imm + 1 
			end
			6'd9: begin //SDW
				ALU_Op = 1; // Reg(Rs) + Imm or Reg(Rs) + Imm + 1
			end
			6'd10: begin // BZ
				ALU_Op = 3;
			end
			6'd11: begin // BGZ
				ALU_Op = 3;
			end
			6'd12: begin // BLZ
				ALU_Op = 3;
			end
			6'd13: begin // JR

			end
			6'd14: begin //J
				ALU_Op = 1; // Reg(Rs) + Imm
			end
			6'd15: begin // CLL
				ALU_Op = 1; // Reg(Rs) + Imm
			end	
		endcase
	end
	endmodule