module Imm_Extender(Immediate , sel , Extended);
	input [13:0] Immediate;
	input sel;
	output reg [31:0] Extended;
	
	always @(*) begin
		if(!sel) Extended = {18'b0,Immediate};
		else Extended = {{18{Immediate[13]}},Immediate};
	end
	endmodule
	
	module Ext_test();
		reg [13:0] Imm;
		reg s;
		wire [31:0] out;
		Imm_Extender IE(Imm,s,out);
		initial begin
			$monitor("time = %0d, Mode = %b (0->Zero , 1->Signed), Immediate = %b , Extended = %b",$time,s,Imm,out);
			
		#10; s = 0; Imm = 14'b11001100101001;
		#10; s = 1;
		end
	endmodule
	