module Instruction_Memory(input [31:0] address, output reg [31:0] instruction);
	reg [31:0] ROM [1023:0];
	initial begin
		$readmemh("InstrMemo.txt",ROM);
	end
	always @ (*) begin
		instruction = ROM[address];
	end
endmodule  


//test bench for the Instructions Memory
module InstructionMemory_test(); 
	reg [31:0] address;
	wire [31:0] inst;
	
	Instruction_Memory MEM(address,inst);
	
	initial begin
		address = 0;
		//$monitor("time = %0d,		Address = %h ===> 		MEM[address] = Instruction = %h",$time, address, inst);
		repeat(19) begin
			#(10);
			address = address + 1;
		end	
	end
endmodule