module Main_Ctrl(Opcode, last_DW, RegB,RegW, RegW_2, RegWr , ExtOp , AluSrc , MemRd , MemWr , WBdata , DW_inst);
	input [5:0] Opcode;
	input last_DW;
	output reg  RegW_2 , RegWr , ExtOp  , MemRd , MemWr ,WBdata, DW_inst;
	output reg [1:0] RegW,RegB,AluSrc;
	always @(*) begin
		// initial values
		RegB = 0;
		RegW = 0;
		RegW_2 = 0;
		RegWr = 0;
		ExtOp = 0;
        	AluSrc   = 0;
        	MemRd  = 0;
        	MemWr = 0;
		WBdata = 0;
		DW_inst = 0;

		case(Opcode)
			6'd0:begin // OR
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 0;
       	 		MemRd  = 0;
        			MemWr = 0;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd1: begin // ADD 
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 0;
       	 		MemRd  = 0;
        			MemWr = 0;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd2: begin // SUB
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 0;
       	 		MemRd  = 0;
        			MemWr = 0;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd3: begin // CMP
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 0;
       	 		MemRd  = 0;
        			MemWr = 0;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd4: begin // ORI
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 1;
       	 		MemRd  = 0;
        			MemWr = 0;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd5: begin // ADDI
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 1;
       	 		MemRd  = 0;
        			MemWr = 0;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd6: begin // LW
				RegB = 0;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 1;
       	 		MemRd  = 1;
        			MemWr = 0;
				WBdata = 1;
				DW_inst = 0;
			end
			6'd7: begin // SW
				RegB = 1;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 0;
				ExtOp = 0;
       	 		AluSrc   = 1;
        			MemWr = 1;
				WBdata = 0;
				DW_inst = 0;
			end
			6'd8: begin // LDW
        		if (last_DW) begin
				RegB = 2;
				RegW = 2;
				RegW_2 = 0;
				RegWr = 1;
				ExtOp = 0;
       	 		AluSrc   = 2;
       	 		MemRd  = 1;
        			MemWr = 0;
				WBdata = 1;
				DW_inst = 0;
        		end else begin
				RegB = 1;
				RegW = 0;
				RegW_2 = 0;
				RegWr = 1;
				ExtOp = 0;
       	 		AluSrc   = 1;
       	 		MemRd  = 1;
        			MemWr = 0;
				WBdata = 1;
				DW_inst = 1;
				end
			end
			6'd9: begin //SDW
				RegB <= 1; AluSrc <= 1; MemWr <= 1;
                    if (last_DW == 1) begin
                        RegW <= 2;
                        RegB <= 2;
						AluSrc <=2;
                        DW_inst = 0;
                    end else begin
                        DW_inst <= 1; // trigger stall for 2 cycles
                    end
			end
			6'd10: begin // BZ
				ExtOp = 1; 
			end
			6'd11: begin // BGZ
				ExtOp = 1;
			end
			6'd12: begin // BLZ
				ExtOp = 1;
			end
			6'd13: begin // JR
			end
			6'd14: begin //J
				ExtOp = 1;
			end
			6'd15: begin // CLL
				ExtOp = 1; RegW = 1; RegWr = 1; RegW_2 = 1;
			end	
		endcase
		end
		
		
endmodule


module tb_Main_Ctrl;

    // Inputs
    reg [5:0] Opcode;
	reg [1:0] DW_s;
	reg Clk, last_S;

    // Outputs
    wire  RegW_2, RegWr, ExtOp, MemRd, MemWr, WBdata, Stall;
	wire [1:0]  RegW,RegB,AluSrc;

    // Instantiate the Unit Under Test (UUT)
    Main_Ctrl uut (
		.Opcode(Opcode),
		.last_DW(last_S),
        .RegB(RegB),
        .RegW(RegW),
        .RegW_2(RegW_2),
        .RegWr(RegWr),
        .ExtOp(ExtOp),
        .AluSrc(AluSrc),
        .MemRd(MemRd),
        .MemWr(MemWr),
        .WBdata(WBdata),
        .DW_inst(Stall)
    );

    // Task to display outputs
    task display_outputs;
        begin
            #1; // Wait for combinational logic to settle
            $display("Opcode: %2d | RegB: %b | RegW: %b | RegW_2: %b | RegWr: %b | ExtOp: %b | AluSrc: %b | MemRd: %b | MemWr: %b | WBdata: %b | Stall: %b",
                     Opcode, RegB, RegW, RegW_2, RegWr, ExtOp, AluSrc, MemRd, MemWr, WBdata, Stall);
        end
    endtask
	initial begin
        Clk = 0; last_S=0;
    end
    initial begin
        $display("=== Starting Main_Ctrl Testbench ===");

        // Loop through all opcode values
       Opcode = 0;
    while (Opcode < 16) begin
        Clk = ~Clk; #1;
        Clk = ~Clk; #1; // Full clock cycle
		display_outputs();
		last_S = Stall;

        if (!Stall)
            Opcode = Opcode + 1;
    end

        $display("=== Testbench Finished ===");
        $stop;
    end

endmodule