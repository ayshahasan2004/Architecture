module Mux2_1_31bit (input  [31:0] in0, input  [31:0] in1, input sel, output [31:0] out);
    assign out = (sel == 0) ? in0 : in1;
endmodule 

module Mux2_1_4bit (input  [3:0] in0, input  [3:0] in1, input sel, output [3:0] out);
    assign out = (sel == 0) ? in0 : in1;
endmodule